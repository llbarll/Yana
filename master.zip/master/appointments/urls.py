from django.conf.urls import url 
from . import views
from appointments.views import appointmentsdetail
from django.urls import path
from django.views.generic import TemplateView



urlpatterns = [
	url(r'^$',views.index ,name='index'),
	path("manage", views.manage, name='manage'),
	path("add", views.add, name="add"),
	path("edit", views.edit, name="edit"),
	path("delete", views.delete, name="delete"),
	path("view_appointment", TemplateView.as_view(template_name="appointment_files/view_appointment.html"), name="view_appointment"),
	path("appointment_added", TemplateView.as_view(template_name="appointment_files/appointment_added.html"), name="appointment_added"),
	path("appointment_deleted", TemplateView.as_view(template_name="appointment_files/appointment_deleted.html"), name="appointment_deleted"),
	path("appointment_edited", TemplateView.as_view(template_name="appointment_files/appointment_edited.html"), name="appointment_edited"),

]