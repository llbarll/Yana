from django.db import models

# Create your models here.

class appointments(models.Model):
	first_name = models.CharField(max_length=200)
	last_name  = models.CharField(max_length=200)
	center = models.ForeignKey('appointments', blank=False, max_length=100, on_delete=models.CASCADE, related_name='cen')
	doctor = models.ForeignKey('appointments', max_length=40, on_delete=models.CASCADE, related_name='doc')
	time_field = models.TimeField(blank=True, null=True)
	date_field = models.DateField(blank=True, null=True)
	doctor_name  = models.ForeignKey('appointments', max_length=40, on_delete=models.CASCADE, related_name='doc_name')

	def __str__(self):
		return self.appointment_title


