from django.shortcuts import render
from appointments.models import appointments
from appointments.forms import appointmentForm
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.views.generic import DetailView
from django.template.context_processors import request
from django.contrib import messages


# Create your views here.
class appointmentsdetail(DetailView):
	template_name = 'appointment_files/view_appointment.html'
	model = appointments

def index(request):
	return render(request, 'appointment_files/index.html')

def manage(request):
	return render(request, 'appointment_files/manage.html')
	
def add(request):
    if request.method == "POST":
        form = appointmentForm(request.POST)

        if form.is_valid():
            data = form.cleaned_data

            appointment = appointments()

            # Stock django User model fields
            appointment.first_name = data['first_name']
            appointment.last_name = data['last_name']
            appointment.center = data['center']
            appointment.doctor = data['doctor']
            appointment.time_field = data['time_field']
            appointment.date_field = data['date_field']
            appointment.doctor_name = data['doctor_name']
            
            appointment.save()
            
            return HttpResponseRedirect(reverse("appointment_added"))
    else:
        form = appointmentForm()

    return render(request, "appointment_files/add.html", {"form": form})


def delete(request):
	form = appointmentForm(request.POST)
	instance = appointments.objects.all()
	for x in instance:
		if x==form:
			appointments.objects.filter(id=id).delete() 
			messages.success(request, 'Form submission successful')
	return HttpResponseRedirect(reverse("appointment_deleted"))

def edit(request):
	delete(request)
	add(request)
	messages.success(request, 'Form submission successful')
	return HttpResponseRedirect(reverse("appointment_edited"))


