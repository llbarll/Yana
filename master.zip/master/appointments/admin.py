from django.contrib import admin
from .models import appointments
# Register your models here.
admin.site.register(appointments)